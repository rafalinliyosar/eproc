import React from 'react';
import ReactDOM from "react-dom";
import { BrowserRouter as Router } from 'react-router-dom';
import App from './App';
import { Provider } from 'react-redux';
import  {Store,persistor} from './store'
import { PersistGate } from 'redux-persist/integration/react'


// let storeInstance = Store()

ReactDOM.render(
    <Router>
    <Provider store={Store}>
    <PersistGate persistor={persistor}>
            <App />
        </PersistGate>
    </Provider>
    </Router>

    , document.getElementById('root'));



